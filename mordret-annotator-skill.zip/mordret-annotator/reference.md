# Mordret v3 — format and resolution contract

Everything here is enforced by Audiobook Maker's `mordret.py` /
`app.py`. `mordret_tools.py validate` checks all of it.

## Why the format stores no book text

A Mordret file contains only short *anchor* phrases marking where each
speaker's turn begins — never the book's prose. At generation time the app
re-extracts the text from the user's own book file and locates the anchors
in it. That keeps annotation copyright-safe: the audio is always produced
from the user's own legally obtained file.

This is also why anchors must match exactly — they are the only link
between the annotation and the text.

## Schema

```json
{
  "mordret_version": 3,
  "source_file": "book.epub",
  "characters": [
    {"id": "watson", "name": "Dr. Watson", "slot": "M1"}
  ],
  "slots": [
    {"id": "NARRATOR", "description": "..."}
  ],
  "chapters": [
    {
      "chapter_index": 1,
      "chapter_title": "Chapter 1",
      "lines": [
        {"speaker": "NARRATOR", "anchor_start": "The rain had not stopped"},
        {"speaker": "watson",   "anchor_start": "\"You're late,\""}
      ]
    }
  ]
}
```

Hard requirements (`load_mordret_file` raises `ValueError` otherwise):

| Field | Rule |
|---|---|
| `mordret_version` | must be exactly `3` (integer) |
| `characters`, `slots`, `chapters` | must all be present |
| `line.speaker` | must be a `characters[].id`, or the literal `"NARRATOR"` |
| `character.slot` | one of `NARRATOR M1 M2 M3 F1 F2 F3` |
| `chapter_index` | 1-based index into `text.extract_chapters(book)`; out-of-range chapters are skipped with a warning |
| `source_file` | basename only; a mismatch warns but still generates |

`chapter_title` is optional — the app falls back to the real chapter title.

## How anchors resolve

`find_anchor_positions` walks the anchors in order:

```python
idx = source_text.find(anchor, pos)
if idx == -1:
    positions.append(last_good)   # silently merges into the previous line
else:
    positions.append(idx)
    pos = idx + len(anchor)       # search continues AFTER this anchor
```

Each line's spoken text runs from its own anchor to the **next** anchor.
Consequences that drive the whole design:

1. **Anchors must be exact substrings.** A missed anchor does not error —
   it merges that line into the previous speaker. Silent voice loss.
2. **Search is forward-only.** Anchors must appear in document order.
3. **Anchors must not overlap.** An anchor extending past the next
   anchor's start pushes `pos` beyond it, so the next one mis-resolves.
   Anchor length is therefore capped at `next_offset - offset`.
4. **A run of one speaker needs exactly one anchor.** Since a segment
   extends to the next anchor, emitting an anchor per paragraph is pure
   waste. Emit one only where the speaker *changes*.
5. **Avoid the empty-anchor sentinel.** `""` resolves to the last good
   position but does not advance `pos`, so an identical phrase right
   after it cannot be disambiguated. Always use a real anchor.

## What text anchors match against

The app resolves anchors against `text.clean_text(raw_chapter_text)` —
**not** the raw file, and **not** the speech-normalized text:

```python
cleaned  = textmod.clean_text(raw_text)                      # anchors match THIS
resolved = mordretmod.resolve_chapter_lines(cleaned, lines)
...
normalized = textmod.normalize_for_speech(text)              # happens AFTER
```

So an anchor must reflect what `clean_text` produces:

- each line is `.strip()`ed; runs of 2+ spaces collapse to one
- standalone page-number lines are removed
- running headers/footers (short lines repeating at regular intervals) are removed
- `develop-\nment` line-wrap hyphenation is joined to `development`
- 3+ blank lines collapse to two

and it must **keep original punctuation**, because normalization runs
later: curly quotes `“ ” ’`, em dashes `—`, and `!!!` are still present at
anchor-matching time. An anchor written with straight quotes will not
match text that uses curly ones.

`mordret_tools.py` sidesteps all of this by slicing anchors directly out
of the cleaned text — which is exactly why anchors should never be typed
by hand.

## Anchor generation algorithm

For a segment starting at `offset`, with the next segment at
`next_offset`, and the resolver's cursor at `search_from`:

1. Cap length at `min(60, next_offset - offset)` — guarantees no overlap.
2. Starting at 24 chars, grow by 8 until
   `text.find(candidate, search_from) == offset` — guarantees the resolver
   lands on the intended occurrence, not an earlier identical one.
3. If no length in that window is unique, emit nothing and merge the
   segment into the previous line, with a visible warning. This happens
   only when two identical short quotes are directly adjacent, where no
   correct anchor exists.

Then `validate` independently re-resolves the finished file and asserts
the segments reconstruct the chapter at 100.00% coverage.

## Failure modes and what they mean

| Symptom | Cause | Fix |
|---|---|---|
| `FAIL: anchor not present in text` | anchor hand-written, or book edited since | regenerate with `build` |
| `FAIL: segments do not reconstruct` | overlapping or out-of-order anchors | regenerate with `build` |
| coverage < 100% | text would be lost in the audiobook | do not ship; regenerate |
| `warning: no unique anchor` | adjacent identical quotes | usually fine; many = report it |
| `warn source_file is X but book is Y` | annotated against a different file | re-run against the actual book |
| every line is `NARRATOR` | assignment file never applied | check span numbers match `scan` |

## Generation-side behaviour worth knowing

- Empty/whitespace-only segments are dropped before TTS.
- Over-long single lines are re-chunked automatically; resume and joining
  stay per-line.
- Slots with no voice assigned fall back to the user's single selected
  voice rather than failing.
- Chapter folders/files keep the **real** chapter numbers, so a partial
  run lines up with the full book.
