#!/usr/bin/env python3
"""
mordret_tools.py -- build and verify Mordret v3 multi-voice annotation files
for Audiobook Maker.

Design rule that makes this reliable: **anchors are generated mechanically
from the real cleaned chapter text, never typed by hand or by a model.**
The model's only job is deciding *who speaks* each quoted span; every
fragile string operation (exact substring match, forward-search ordering,
non-overlap) is handled here and then independently re-verified.

Subcommands
-----------
  chapters  BOOK                         list chapters + dialogue counts
  scan      BOOK --chapter N             compact numbered dialogue digest
  build     BOOK --assign A -o OUT       generate the .mordret.json
  validate  MORDRET BOOK                 prove it resolves losslessly

All text is read through Audiobook Maker's own text.py so the anchors are
matched against byte-identical text to what the generator will see.
"""

import argparse
import json
import os
import re
import sys

ANCHOR_MIN = 24        # shortest anchor we'll try
ANCHOR_MAX = 60        # longest anchor we'll store
ANCHOR_STEP = 8        # growth step when disambiguating
MIN_SEGMENT = 25       # merge segments shorter than this into the previous one

OPEN_QUOTES = '"“'
CLOSE_QUOTES = '"”'

SLOT_IDS = ("NARRATOR", "M1", "M2", "M3", "F1", "F2", "F3")


# ---------------------------------------------------------------------------
# Locating Audiobook Maker so we reuse its exact text pipeline
# ---------------------------------------------------------------------------

def _looks_like_app(path):
    return bool(path) and os.path.isfile(os.path.join(path, "text.py")) \
        and os.path.isfile(os.path.join(path, "mordret.py"))


def load_app_modules(app_dir=None):
    # An explicitly supplied location is strict: silently falling back to
    # some other install would resolve anchors against a different
    # clean_text(), producing a file that validates here but breaks there.
    explicit = app_dir or os.environ.get("AUDIOBOOK_MAKER_DIR")
    if explicit and not _looks_like_app(explicit):
        sys.exit(
            f"'{explicit}' is not an Audiobook Maker folder (no text.py + mordret.py).\n"
            "Point --app-dir / AUDIOBOOK_MAKER_DIR at the real folder, or omit it to autodetect."
        )

    candidates = []
    if explicit:
        candidates.append(explicit)
    candidates += [
        os.getcwd(),
        os.path.join(os.getcwd(), "audiobook-maker"),
        os.path.expanduser("~/Desktop/audiobook-maker"),
        os.path.expanduser("~/audiobook-maker"),
    ]
    for cand in candidates:
        if cand and os.path.isfile(os.path.join(cand, "text.py")) \
                and os.path.isfile(os.path.join(cand, "mordret.py")):
            sys.path.insert(0, cand)
            import text as textmod
            import mordret as mordretmod
            return textmod, mordretmod, cand
    sys.exit(
        "Could not find the Audiobook Maker folder (needs text.py + mordret.py).\n"
        "Pass --app-dir /path/to/audiobook-maker, or set AUDIOBOOK_MAKER_DIR."
    )


def cleaned_chapters(textmod, book_path):
    """The exact (title, cleaned_text) list the generator resolves against."""
    raw = textmod.extract_chapters(book_path)
    return [(title, textmod.clean_text(body)) for title, body in raw]


# ---------------------------------------------------------------------------
# Dialogue detection
# ---------------------------------------------------------------------------

def find_quote_spans(text):
    """Return [(start, end)] for each double-quoted span, end exclusive.

    Handles straight quotes (paired by order) and curly quotes (paired by
    direction). Unclosed quotes are skipped rather than swallowing the rest
    of the chapter.
    """
    spans = []
    i = 0
    n = len(text)
    while i < n:
        ch = text[i]
        if ch == "“":                      # curly open
            j = text.find("”", i + 1)
            if j == -1:
                break
            spans.append((i, j + 1))
            i = j + 1
        elif ch == '"':                          # straight: next " closes it
            j = text.find('"', i + 1)
            if j == -1:
                break
            spans.append((i, j + 1))
            i = j + 1
        else:
            i += 1
    return spans


_SAID_VERBS = (
    # English
    "said|asked|replied|answered|shouted|whispered|murmured|muttered|cried|"
    "called|added|continued|began|snapped|growled|laughed|sighed|repeated|"
    "explained|admitted|insisted|demanded|offered|responded|declared|noted|"
    # Uzbek (Latin) -- "dedi Watson" / "Watson so'radi" both occur
    "dedi|so'radi|soradi|so‘radi|javob berdi|aytdi|qichqirdi|pichirladi|"
    "so'zladi|sozladi|davom etdi|qo'shimcha qildi|takrorladi|luqma tashladi|"
    "gapirdi|xitob qildi|ming'irladi|"
    # Russian
    "сказал|сказала|спросил|спросила|ответил|ответила|крикнул|прошептал"
)
# Name = a capitalised word (Latin or Cyrillic), optionally two words.
_NAME = r"[A-ZА-ЯЁ][\w'’\-]*(?:\s+[A-ZА-ЯЁ][\w'’\-]*)?"
_ATTR_AFTER = re.compile(
    r"^[,.!?\s”\"'’]*(?:(?P<v1>" + _SAID_VERBS + r")\s+(?P<n1>" + _NAME + r")"
    r"|(?P<n2>" + _NAME + r")\s+(?P<v2>" + _SAID_VERBS + r"))",
)
_ATTR_BEFORE = re.compile(
    r"(?P<n>" + _NAME + r")\s+(?:" + _SAID_VERBS + r")[,:\s]*$",
)


def attribution_hint(text, start, end, window=70):
    """A short 'said X' style hint around a quote, to help assign a speaker
    without shipping the whole surrounding paragraph into context."""
    after = text[end:end + window].replace("\n", " ")
    m = _ATTR_AFTER.match(after)
    if m:
        return (m.group("n1") or m.group("n2") or "").strip()
    before = text[max(0, start - window):start].replace("\n", " ")
    m = _ATTR_BEFORE.search(before)
    if m:
        return m.group("n").strip()
    return ""


def shorten(s, limit=64):
    s = " ".join(s.split())
    return s if len(s) <= limit else s[:limit - 1] + "…"


# ---------------------------------------------------------------------------
# Anchor generation (the part that must never be done by hand)
# ---------------------------------------------------------------------------

def make_anchor(text, offset, next_offset, search_from):
    """Smallest anchor at `offset` that a forward search from `search_from`
    resolves to `offset` exactly, and that stops before `next_offset` so
    consecutive anchors can never overlap.

    Returns (anchor, ok). ok=False means no anchor could be made unique --
    the caller should merge this segment instead of emitting a bad one.
    """
    hard_cap = ANCHOR_MAX
    if next_offset is not None:
        hard_cap = min(hard_cap, next_offset - offset)
    if hard_cap <= 0:
        return "", False

    available = min(hard_cap, len(text) - offset)
    length = min(ANCHOR_MIN, available)
    while length <= available:
        cand = text[offset:offset + length]
        if cand.strip() and text.find(cand, search_from) == offset:
            return cand, True
        if length == available:
            break
        length = min(length + ANCHOR_STEP, available)
    return text[offset:offset + available], False


def build_segments(text, quote_spans, assignment):
    """Turn {quote_index: speaker_id} into ordered (offset, speaker)
    segments covering the whole chapter, narration included."""
    events = []
    for idx_str, speaker in assignment.items():
        try:
            qi = int(idx_str)
        except (TypeError, ValueError):
            continue
        if not (1 <= qi <= len(quote_spans)) or not speaker:
            continue
        if str(speaker).upper() == "NARRATOR":
            continue
        start, end = quote_spans[qi - 1]
        events.append((start, end, speaker))
    events.sort()

    segments = []          # (offset, speaker)
    cursor = 0
    for start, end, speaker in events:
        if start < cursor:
            continue        # overlapping assignment; skip the later one
        if start > cursor:
            segments.append((cursor, "NARRATOR"))
        segments.append((start, speaker))
        cursor = end
    if cursor < len(text):
        segments.append((cursor, "NARRATOR"))

    # Collapse consecutive same-speaker runs: a segment already extends to
    # the next anchor, so a run of one speaker needs exactly one anchor.
    merged = []
    for offset, speaker in segments:
        if merged and merged[-1][1] == speaker:
            continue
        merged.append((offset, speaker))

    # Drop slivers (stray punctuation between quotes) by folding them back.
    pruned = []
    for i, (offset, speaker) in enumerate(merged):
        nxt = merged[i + 1][0] if i + 1 < len(merged) else len(text)
        if pruned and (nxt - offset) < MIN_SEGMENT and not text[offset:nxt].strip():
            continue
        pruned.append((offset, speaker))

    final = []
    for offset, speaker in pruned:
        if final and final[-1][1] == speaker:
            continue
        final.append((offset, speaker))
    return final


def segments_to_lines(text, segments):
    """Emit Mordret `lines`, generating and self-checking each anchor."""
    lines, warnings = [], []
    search_from = 0
    i = 0
    while i < len(segments):
        offset, speaker = segments[i]
        next_offset = segments[i + 1][0] if i + 1 < len(segments) else None
        # Note: even the first segment at offset 0 gets a *real* anchor.
        # The empty-anchor sentinel would resolve to 0 correctly, but it
        # leaves the resolver's forward-search cursor at 0, which makes an
        # immediately-following identical phrase impossible to pin down.
        # A real anchor advances the cursor and keeps later anchors unique.
        anchor, ok = make_anchor(text, offset, next_offset, search_from)
        if not ok:
            warnings.append(
                f"offset {offset}: no unique anchor (segment merged into the previous line)"
            )
            i += 1
            continue
        lines.append({"speaker": speaker, "anchor_start": anchor})
        search_from = offset + len(anchor)
        i += 1
    return lines, warnings


# ---------------------------------------------------------------------------
# Subcommands
# ---------------------------------------------------------------------------

def cmd_chapters(args):
    textmod, _, _ = load_app_modules(args.app_dir)
    chapters = cleaned_chapters(textmod, args.book)
    print(f"{os.path.basename(args.book)} — {len(chapters)} chapter(s)\n")
    print(f"{'idx':>4}  {'chars':>7}  {'quotes':>6}  title")
    for i, (title, body) in enumerate(chapters, start=1):
        print(f"{i:>4}  {len(body):>7}  {len(find_quote_spans(body)):>6}  {shorten(title, 48)}")
    total = sum(len(find_quote_spans(b)) for _, b in chapters)
    print(f"\ntotal quoted spans: {total}")


def cmd_scan(args):
    textmod, _, _ = load_app_modules(args.app_dir)
    chapters = cleaned_chapters(textmod, args.book)
    if not (1 <= args.chapter <= len(chapters)):
        sys.exit(f"chapter {args.chapter} out of range (book has {len(chapters)})")
    title, body = chapters[args.chapter - 1]
    spans = find_quote_spans(body)

    print(f"# chapter {args.chapter}: {title}")
    print(f"# {len(body)} chars, {len(spans)} quoted spans")
    print("# assign a speaker id to each index; anything unassigned = NARRATOR")
    if not spans:
        print("\n(no dialogue found — this chapter is pure narration)")
        return
    print()
    for n, (s, e) in enumerate(spans, start=1):
        hint = attribution_hint(body, s, e)
        hint_txt = f"   <- {hint}" if hint else ""
        print(f"{n:>4}. {shorten(body[s:e], args.width)}{hint_txt}")


def cmd_build(args):
    textmod, _, app_dir = load_app_modules(args.app_dir)
    with open(args.assign, encoding="utf-8") as f:
        plan = json.load(f)

    characters = plan.get("characters", [])
    known = {c["id"] for c in characters}
    for c in characters:
        if c.get("slot") not in SLOT_IDS:
            sys.exit(f"character {c.get('id')!r} has invalid slot {c.get('slot')!r}; "
                     f"must be one of {', '.join(SLOT_IDS)}")
    if len(known) != len(characters):
        sys.exit("duplicate character ids in the assignment file")

    chapters = cleaned_chapters(textmod, args.book)
    out_chapters, all_warnings = [], []

    for ch_key, assignment in sorted(plan.get("chapters", {}).items(), key=lambda kv: int(kv[0])):
        ci = int(ch_key)
        if not (1 <= ci <= len(chapters)):
            all_warnings.append(f"chapter {ci}: out of range, skipped")
            continue
        title, body = chapters[ci - 1]
        spans = find_quote_spans(body)

        for qi, speaker in assignment.items():
            if speaker and str(speaker).upper() != "NARRATOR" and speaker not in known:
                sys.exit(f"chapter {ci} quote {qi}: unknown speaker id {speaker!r}")

        segments = build_segments(body, spans, assignment)
        lines, warns = segments_to_lines(body, segments)
        all_warnings += [f"chapter {ci}: {w}" for w in warns]
        if lines:
            out_chapters.append({
                "chapter_index": ci,
                "chapter_title": title,
                "lines": lines,
            })

    doc = {
        "mordret_version": 3,
        "source_file": os.path.basename(args.book),
        "characters": characters,
        "slots": [{"id": s, "description": _slot_description(s)} for s in SLOT_IDS],
        "chapters": out_chapters,
    }

    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(doc, f, ensure_ascii=False, indent=2)

    n_lines = sum(len(c["lines"]) for c in out_chapters)
    print(f"wrote {args.out}")
    print(f"  {len(characters)} character(s), {len(out_chapters)} chapter(s), {n_lines} line(s)")
    for w in all_warnings:
        print(f"  warning: {w}")

    print()
    _validate(args.out, args.book, args.app_dir, strict=args.strict)


def _slot_description(slot):
    if slot == "NARRATOR":
        return "Narration and everything not attributed to a character"
    return ("Male character " if slot.startswith("M") else "Female character ") + slot[1:]


def cmd_validate(args):
    _validate(args.mordret, args.book, args.app_dir, strict=args.strict)


def _validate(mordret_path, book_path, app_dir, strict=False):
    """Independent proof that the file the generator loads resolves exactly
    as intended: anchors all match, coverage is total, no empty segments."""
    textmod, mordretmod, _ = load_app_modules(app_dir)

    try:
        doc = mordretmod.load_mordret_file(mordret_path)
    except ValueError as e:
        sys.exit(f"FAIL: the app itself rejects this file: {e}")
    print("ok   schema accepted by the app's own load_mordret_file()")

    if not mordretmod.source_file_matches(doc, book_path):
        print(f"warn source_file is {doc.get('source_file')!r} but book is "
              f"{os.path.basename(book_path)!r}")

    chapters = cleaned_chapters(textmod, book_path)
    problems, total_lines, total_chars, covered_chars = 0, 0, 0, 0

    for mch in doc["chapters"]:
        ci = mch["chapter_index"]
        if not (1 <= ci <= len(chapters)):
            print(f"FAIL chapter {ci}: out of range for this book")
            problems += 1
            continue
        _, body = chapters[ci - 1]
        specs = mch["lines"]
        resolved = mordretmod.resolve_chapter_lines(body, specs)

        # every anchor must be found (not silently folded into the previous)
        anchors = [s["anchor_start"] for s in specs]
        positions = mordretmod.find_anchor_positions(body, anchors)
        for n, (a, p) in enumerate(zip(anchors, positions), start=1):
            if a and body.find(a, 0) == -1:
                print(f"FAIL chapter {ci} line {n}: anchor not present in text: {a[:40]!r}")
                problems += 1
            elif a and body[p:p + len(a)] != a:
                print(f"FAIL chapter {ci} line {n}: anchor resolved to the wrong place")
                problems += 1

        # lossless reconstruction: concatenating segments must rebuild the text
        rebuilt = "".join(r["text"] for r in resolved)
        total_chars += len(body)
        covered_chars += len(rebuilt)
        if rebuilt != body:
            print(f"FAIL chapter {ci}: segments do not reconstruct the chapter "
                  f"({len(rebuilt)} vs {len(body)} chars)")
            problems += 1

        empties = sum(1 for r in resolved if not r["text"].strip())
        if empties:
            print(f"warn chapter {ci}: {empties} empty segment(s) (they are dropped at generation)")
        total_lines += len(specs)

    pct = (100.0 * covered_chars / total_chars) if total_chars else 100.0
    print(f"ok   {len(doc['chapters'])} chapter(s), {total_lines} line(s)")
    print(f"ok   text coverage {pct:.2f}%  ({covered_chars}/{total_chars} chars)")

    slots_used = {}
    for mch in doc["chapters"]:
        for line in mch["lines"]:
            slots_used[line["speaker"]] = slots_used.get(line["speaker"], 0) + 1
    print("     lines per speaker: " + ", ".join(
        f"{k}={v}" for k, v in sorted(slots_used.items(), key=lambda kv: -kv[1])))

    if problems:
        sys.exit(f"FAIL: {problems} problem(s) found")
    print("PASS: file is valid and resolves losslessly")
    if strict:
        unassigned = [k for k, v in slots_used.items() if k == "NARRATOR"]
        if len(slots_used) == 1 and unassigned:
            sys.exit("FAIL (strict): every line is NARRATOR — no character was assigned")


def main():
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--app-dir", help="path to the audiobook-maker folder")
    sub = p.add_subparsers(dest="cmd", required=True)

    c = sub.add_parser("chapters", help="list chapters and dialogue counts")
    c.add_argument("book")
    c.set_defaults(func=cmd_chapters)

    s = sub.add_parser("scan", help="compact numbered dialogue digest for one chapter")
    s.add_argument("book")
    s.add_argument("--chapter", type=int, required=True)
    s.add_argument("--width", type=int, default=64, help="max quote chars shown")
    s.set_defaults(func=cmd_scan)

    b = sub.add_parser("build", help="generate the .mordret.json from an assignment file")
    b.add_argument("book")
    b.add_argument("--assign", required=True)
    b.add_argument("-o", "--out", required=True)
    b.add_argument("--strict", action="store_true")
    b.set_defaults(func=cmd_build)

    v = sub.add_parser("validate", help="prove a mordret file resolves losslessly")
    v.add_argument("mordret")
    v.add_argument("book")
    v.add_argument("--strict", action="store_true")
    v.set_defaults(func=cmd_validate)

    args = p.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
