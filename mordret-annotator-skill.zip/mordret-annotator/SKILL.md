---
name: mordret-annotator
description: Create a Mordret v3 multi-voice annotation file (book.mordret.json) for Audiobook Maker, so each character in a book is narrated by a different voice. Use when the user wants multi-voice or character voices for an audiobook, mentions Mordret, or asks to annotate who speaks which lines in a PDF/EPUB/TXT book. Handles large books without exhausting context.
---

# Mordret Annotator

Produce a `book.mordret.json` that Audiobook Maker reads to narrate each
character in a different voice.

## The one rule that makes this reliable

**Never write an `anchor_start` value yourself.** Anchors must be exact
substrings of the book's *cleaned* text, must appear in forward order, and
must not overlap. Hand-written anchors silently fail to match, and the
generator then merges that line into the previous one — losing the
character voice with no error.

`scripts/mordret_tools.py build` generates every anchor mechanically from
the real text, so a mismatch is structurally impossible. Your job is only
to decide **who speaks** each quoted span.

## Workflow

Run everything with `--app-dir /path/to/audiobook-maker` (or set
`AUDIOBOOK_MAKER_DIR`) so the tool reads text through the app's own
pipeline. Let `T="python3 <skill>/scripts/mordret_tools.py --app-dir <app>"`.

### 1. Survey the book

```
$T chapters BOOK
```
Prints each chapter's index, size, and quoted-span count. Use it to see
the scale and to spot chapters with no dialogue (skip those entirely —
they are pure narration and need no annotation).

### 2. Work one chapter at a time

```
$T scan BOOK --chapter N
```
Prints a compact numbered list of that chapter's quoted spans, each with
an attribution hint when one is detectable:

```
   1. "You're late,"   <- he
   2. "I couldn't help it,"   <- Holmes
   3. "The bridge was flooded."
```

**Only read this digest — do not read the book file itself.** The digest
is ~90% smaller than the chapter text and contains everything you need.
Read the full chapter with `Read` only if a specific span is genuinely
ambiguous, and then read just that region.

### 3. Assign speakers

Build one assignment file for the whole book:

```json
{
  "characters": [
    {"id": "watson", "name": "Dr. Watson",      "slot": "M1"},
    {"id": "holmes", "name": "Sherlock Holmes", "slot": "M2"},
    {"id": "mary",   "name": "Mary Morstan",    "slot": "F1"}
  ],
  "chapters": {
    "1": {"1": "watson", "2": "holmes", "3": "holmes"},
    "2": {"1": "mary",   "2": "watson"}
  }
}
```

- Keys under `chapters` are chapter indices; inner keys are the span
  numbers from `scan`.
- Anything you leave out defaults to `NARRATOR`. Write `"NARRATOR"`
  explicitly when a quote is not character dialogue (a quoted sign, a
  letter being read aloud by the narrator, scare quotes).
- `slot` must be one of `NARRATOR M1 M2 M3 F1 F2 F3`. There are only
  three male and three female slots — see "Casting" below.
- Keep `id` short and stable; reuse the same id across all chapters.

### 4. Build and verify

```
$T build BOOK --assign assign.json -o BOOK.mordret.json
```

`build` runs `validate` automatically. Both must end with:

```
PASS: file is valid and resolves losslessly
```

If you see `warning: ... no unique anchor`, that span was merged into the
previous line. A few are harmless. Many means the book repeats short
identical dialogue adjacently — report it rather than hiding it.

`validate` can also be run on its own:
```
$T validate BOOK.mordret.json BOOK
```
It checks the app's own loader accepts the file, every anchor resolves to
its intended position, and the segments reconstruct the chapter text at
**100.00% coverage**. Anything less than 100% means text would be lost —
do not hand the file over.

### 5. Deliver

Save as `<book_stem>.mordret.json` next to the book file. Audiobook Maker
auto-detects that name and offers it on file selection.

## Casting characters into slots

Seven slots exist: `NARRATOR`, `M1`–`M3`, `F1`–`F3`. Books usually have
more characters than slots, so cast deliberately:

- Give `M1`/`F1` to the characters with the most dialogue.
- Share a slot between characters who never appear in the same scene, or
  whose lines are short and clearly attributed in the text.
- Minor characters with a handful of lines can stay `NARRATOR` — that
  reads naturally, and is better than exhausting slots on walk-ons.
- Match slot gender to the character; the app auto-assigns real voices by
  slot gender.

## Token discipline for large books

The whole point of the digest workflow is that a 300-page book never
enters context in full. Measured on a 179k-character book: full text
~44.7k tokens, all 30 chapter digests ~3.9k tokens (**91% less**).

- Never `Read` the book file to annotate it. Use `scan`.
- Process chapter by chapter; append each chapter's assignments to the
  plan file as you go rather than holding them all in your reply.
- Never echo book prose back in your messages. Refer to spans by number.
- For a very long book, write the assignment file incrementally with
  `Edit` instead of regenerating the whole JSON each time.
- Skip chapters `chapters` reports with 0 quotes.

## Details

Read `reference.md` for the exact v3 schema, the anchor-resolution
contract, and how the app's text cleaning affects matching.
